<?php
/**
 * @file
 * Doc api for Commerce checkout by Amazon.
 */

/**
 * Allows to modify the purchase item params sent to the Amazon API query.
 */
function hook_commerce_cba_purchase_items_alter(&$params, $order) {

}


/**
 * Allows to modify the contract charges params sent to the Amazon API query.
 */
function hook_commerce_cba_contract_charges_alter(&$params, $order) {

}
