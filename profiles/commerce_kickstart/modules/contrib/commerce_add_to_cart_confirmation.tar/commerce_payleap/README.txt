Overview
========
PayLeap gateway support for Drupal Commerce module.

Summary
=======
Adds two payment methods:

 * PayLeap direct - directly process a credit card request.

 * PayLeap CardOnFile - Saves the credit card information before processing for
   later use.

Methods
=======
Most implemented through payment forms.
