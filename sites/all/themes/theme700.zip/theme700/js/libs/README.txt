Place 3rd-party javascript files here!

*** PLEASE READ the README.txt in the theme's root before adding any external scripts! ***

* Modernizr
  - Download from: http://www.modernizr.com/
  - Put "modernizr-1.6.min.js" here

* DDBelatedPNG
  - Download from: http://www.dillerdesign.com/experiment/DD_belatedPNG/
  - Put "dd_belatedpng.js" here

* HTML5Shim
  - Download from: http://code.google.com/p/html5shim/
  - Put "html5.js" here

For more information please see the README.txt file in the theme's root directory
